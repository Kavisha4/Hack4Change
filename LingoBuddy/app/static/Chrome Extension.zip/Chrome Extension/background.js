chrome.runtime.onInstalled.addListener(() => {
    console.log('Vernacular Video Learning extension installed.');
  });